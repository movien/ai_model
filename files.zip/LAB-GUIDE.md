# LAB GUIDE — build it in front of them

Nothing here is finished. Every artifact — CLAUDE.md, the skill, the hooks, the
subagent — gets created live while the audience watches. That is the whole
teaching design.

**The pattern for every feature is the same three beats:**

1. **Provoke the problem.** Do the work without the feature and let it go wrong.
2. **Apply the fix live.** Either Claude writes the artifact, or you turn the
   feature on. Read what changed, together.
3. **Re-run and watch it hold.** Same task, different outcome.

Beat 1 is the one people skip and it is the one that teaches. Nobody remembers a
hook they were shown. Everybody remembers the SSH that went through, and then
didn't.

**One feature is different, and say so out loud.** CLAUDE.md, the skill, the
hooks and the subagents are all files *you* write — that is why the session
builds them. **Plan Mode is not.** It ships with the tool; you switch it on with
Shift+Tab. Naming that difference matters, because a room that thinks everything
requires authoring will conclude this is a big project. Half of it is a keystroke.

---

## Setup

```bash
cd campus-core-lab
./reset.sh          # shows the stages
```

`work/` is your live directory. `./reset.sh <n>` wipes and reloads it. Nothing
in `work/` is precious — that is deliberate. If a segment goes sideways, reset
and carry on; if you run the session again next month, you build it again.

Have a second terminal open in `campus-core-lab/` for `./reset.sh` and for the
mid-demo file drop, so you never leave the Claude session.

**Break glass:** `_breakglass/` holds finished versions of everything you build.
If a live build stalls, copy the file in, say "here's one I made earlier," and
keep moving. Do not open it otherwise.

---

# FEATURE 1 — /init, three times

The point is not "run /init". The point is that **/init reads what exists**, so
what you get out depends entirely on what you put in. Three runs, three
outcomes, five minutes.

## 1a — Empty repository

```bash
./reset.sh 0
cd work && claude
```

**PASTE:**
```
/init
```

**SAY:** "Nothing in the directory. Watch what it can tell us."

**WATCH FOR:** a generic skeleton, or questions back, or a CLAUDE.md that
essentially describes an empty folder. It cannot invent a project.

**SAY:** "That's the first lesson and it's the one that saves you a month of
disappointment. This thing is not clever about your network. It's clever about
what it can read. Empty repo, empty answer."

## 1b — Evidence, no CLAUDE.md

```bash
./reset.sh 1
cd work && claude
```

**PASTE:**
```
/init
```

**SAY (while it reads):** "Same command. Now it has two running configs, four
show captures, an inventory, our constraints file and an expected-state file."

**WATCH FOR:** a real CLAUDE.md — it names the directories, works out that this
is a Catalyst core pair, spots the version numbers, notices `output/` is empty.

**Then the important question. PASTE:**
```
Does the CLAUDE.md you just wrote say anything about whether you are allowed to
SSH to these switches?
```

**SAY:** "It doesn't. And it couldn't — that rule isn't in any file it read.
That's not a failure, that's the division of labour. It can describe what our
repository *is*. It cannot know what our team *permits*. That part is ours."

## 1c — Over an existing CLAUDE.md

```bash
./reset.sh 2
cd work && claude
```

Show the thin CLAUDE.md first:
```bash
cat CLAUDE.md
```

**PASTE:**
```
/init
```

**SAY:** "There's already a CLAUDE.md here. Current Claude Code doesn't bulldoze
it — it proposes improvements. Which means running /init again after the
repository grows is a safe habit, not a destructive one."

**WATCH FOR:** suggested additions rather than a replacement file.

---

# FEATURE 2 — CLAUDE.md: turn the draft into a contract

Continue in stage 2, or `./reset.sh 2`.

## 2a — Provoke: the draft has no teeth

**PASTE:**
```
Read CLAUDE.md, then draft the upgrade steps for CORE-1.
```

**WATCH FOR:** it produces something plausible, probably writes it wherever it
likes, may not mention rollback, may not mention which switch goes first, and
almost certainly doesn't tell you what it couldn't verify.

**SAY:** "Nothing wrong with that answer. It's just not a change package. The
file it read described the repository — it didn't tell it what good looks like."

## 2b — Build the contract live

**PASTE:**
```
I want to turn CLAUDE.md into a working contract for this project. Add four
sections and keep the whole file under 200 lines:

1. Safety boundary — repository files only; never SSH, call device APIs, run
   Ansible, or reload equipment; write generated artifacts only under output/.
2. Evidence rules — never invent model, ROMMON, storage, boot or compatibility
   facts; cite the source filename beside every prerequisite; put missing facts
   in output/questions.md.
3. Required package — prechecks, implementation, validation, rollback,
   risk-register, as five separate files.
4. Acceptance gates — standby-first sequencing, an explicit hold point between
   nodes, and a peer-review checklist.

Keep the repository description you already have. Show me the diff before you
write it.
```

**SAY while reading the diff:** "Look at what I just gave it that it could not
have worked out on its own. It could see two switches. It could not know that
HSRP standby goes first. That's tribal knowledge, and this is the moment it
stops living in one engineer's head."

## 2c — Re-run and watch it hold

**PASTE:**
```
Draft the upgrade steps for CORE-1 again.
```

**WATCH FOR:** a different shape entirely — it should now push back on
CORE-1-first, ask about the standby, want to write five files, and start
flagging what it can't verify.

**SAY:** "Same question, five minutes apart. The difference is a text file we
wrote together."

**Optional, if you have 60 seconds — nested rules:**
```
Create current/CLAUDE.md with rules that apply only when you read the captured
configs: these are point-in-time exports, not live state; every conclusion is a
hypothesis until confirmed with a live show command; do not edit anything here.
```
**SAY:** "That file only loads when it touches that directory. Rules live next
to the thing they govern — longest-prefix match, basically."

---

# FEATURE 3 — Plan Mode: the review gate

> **DECK REFERENCE:** slides 19–21.

The feature you don't build. Two minutes of setup, and it changes who decides
what gets written.

**Where the evidence-gap moment now lives.** It used to open the skill segment.
It belongs here instead: in Plan Mode, Claude explores read-only and hands back
a plan — and a good plan *names what it couldn't verify* rather than quietly
filling it in. That is a far better demonstration of the same behaviour, because
the audience sees the gap surfaced as a line item in a document they're being
asked to approve.

## 3a — Provoke: no gate, no review

```bash
./reset.sh 3
cd work && claude
```

**PASTE:**
```
Build the change package for the CORE-1 / CORE-2 upgrade to 17.12.4. Create
prechecks, implementation, validation and rollback under output/.
```

Let it run for ten or fifteen seconds, then **interrupt it (Esc).**

**SAY:** "Stop there. Look at what already happened — it's writing files. Maybe
they're good files. But I never got asked whether standby-first was right for
this topology, I never got asked whether we'd confirmed CORE-2's boot mode, and
I've now got artifacts on disk built on assumptions I never saw. If I disagree
with step one, I'm reviewing a finished document instead of a decision."

```bash
ls output/
```

Whatever landed, delete it: `rm -f output/*.md`

## 3b — Turn on the gate

Press **Shift+Tab**. Point at the status bar.

**SAY:** "PLAN MODE. That's the whole activation. Nothing to install, nothing to
write. Reads, searches and questions still run. Edits don't — they queue up
behind a review gate."

**PASTE the same request, with the boundary made explicit:**
```
Plan the CORE-1 / CORE-2 IOS XE upgrade to 17.12.4.

Use captured evidence only. Do not edit files.

List missing evidence, dependencies, prechecks, sequence, validation, rollback,
and stop conditions.
```

**SAY while it explores:** "Watch what it's allowed to do — reading, grepping,
asking. That's the read-only half of the loop running normally. What's deferred
is anything that touches a file."

**WATCH FOR — and this is the moment:** the plan should carry a *missing
evidence* line naming CORE-2. Its capture is genuinely truncated across the boot
block.

**SAY:** "There it is. Not buried in a paragraph — a line item in a plan I'm
being asked to approve. Both switches are the same model, same version, same
rack. It could have written a completely plausible CORE-2 procedure and not one
of us would have queried it. Instead it's telling me, before anything is
written, that it needs one more show command."

**Then challenge the plan — this is the bit engineers most need to see:**
```
Is the standby-first order correct for this topology? Show me the evidence you
based that on, and tell me what would change if CORE-1 were the standby.
```

**SAY:** "That's the conversation Plan Mode is for. I'm arguing with a proposal,
not editing a deliverable."

**If your build supports it, press Ctrl+G** — opens the plan in your editor for
direct edits. Change a line, save, come back.

**SAY:** "And I can just edit it. It's my plan now, not its plan."

## 3c — Close the gap, replan

**Second terminal:**
```bash
cp work/_presenter-dropin/core2-recapture.txt work/evidence/core2-recapture.txt
```

**PASTE:**
```
The CORE-2 re-capture arrived at evidence/core2-recapture.txt. Update the plan.
Do the two switches need the same upgrade procedure or different ones?
```

**WATCH FOR:** CORE-1 is INSTALL mode, CORE-2 is BUNDLE mode — two different
procedures. CORE-2 is also tight on flash.

**SAY:** "Same plan, one file later, and the shape of the change is completely
different. `install add activate commit` on one box, copy-the-bin-and-swap-the-
boot-statement on the other. Had we let it write files in the first thirty
seconds, half that package would have been wrong and we'd have found out at
23:30 with the window open."

## 3d — Approve, and choose how much rope

Approve the plan. **Choose "review each edit manually."**

**SAY:** "Note what I was offered: auto, accept edits, review each edit manually,
or keep planning. For a room learning this on a change that touches core
switches, manual review every time. Auto is for a scratch repo, not for this.
And 'keep planning' is a real option — if the plan still has gaps, you don't
approve it."

Approve a couple of edits so the room sees the per-edit prompt, then:

```bash
git status && git diff --stat
```

**SAY:** "Nothing reached disk until I said so, and everything that did is in a
diff I can read. That's a review gate — the same one we already apply to
config."

---

**One caveat to state plainly, because someone will assume otherwise:**

**SAY:** "Plan Mode stops accidental edits. It does not check whether the
networking is right. Nothing here verified that 17.12.4 is supported on this
hardware, or that the flash arithmetic is correct. It stopped it writing;
*you* still have to read it."


---

# FEATURE 4 — the skill: extract it from the plan you just approved

The mistake is writing a skill first. You write a skill **after** you've done
the thing once and want it repeatable.

## 4a — Notice you just did something worth keeping

You are still in the session from Feature 3, with an approved plan and a package
on disk. Do not reset.

**SAY:** "Rewind five minutes in your head. What did we actually just do? Read
the inventory and both configs. Pulled installation mode, boot statement, free
space and ROMMON for each switch, citing the file each fact came from. Spotted
what was missing and refused to fill it in. Worked out the standby-first
sequence. Wrote implementation, validation and rollback.

That's a procedure. And we're going to do it again for wave two, and wave three,
and every upgrade after that. Right now it exists in exactly one place — the
scrollback of my terminal, which I'm going to close."

## 4b — Build the skill from what just happened

**PASTE:**
```
That workflow is one we'll repeat for every upgrade wave. Turn it into a skill
at .claude/skills/prepare-iosxe-upgrade/SKILL.md.

Frontmatter: name, a description written the way an engineer would actually ask
for this, argument-hint "[device-group] [target-version]",
disable-model-invocation: true so it only runs when invoked by name,
allowed-tools limited to Read Grep Glob, and effort: high.

Body: the four steps we just did — validate inputs and write unknowns to
questions.md, extract state with citations, draft standby-first implementation
plus validation plus rollback, then report gaps and risks. Include the rule
that a blocking fact you cannot cite stops that device's implementation
section.
```

**SAY:** "Notice where the skill came from. We didn't design it in the abstract.
We did the job once, it went well, and now we're making it repeatable. That's
the right order — and it's why your best skills will come from your best
engineers' actual sessions."

**Then show progressive disclosure. PASTE:**
```
The sequencing rules and the rollback patterns are long and we don't need them
in context every session. Move them into
.claude/skills/prepare-iosxe-upgrade/references/ as sequencing-guide.md and
rollback-patterns.md, and have SKILL.md point at them.
```

**SAY:** "Now the skill is an index. The chapters get read only when the work
needs them. Fifty runbooks cost you nothing until you open one."

## 4c — Run it on a clean slate

```bash
./reset.sh 3          # second terminal — wipes the package we just built
```
Restart the session so the skill loads, then re-enter Plan Mode (**Shift+Tab**).

**PASTE:**
```
/prepare-iosxe-upgrade core-pair 17.12.4
```

**WATCH FOR:** the same plan we spent ten minutes arguing our way to — including
the CORE-2 evidence gap — arriving from one line.

**SAY:** "That's the two features working together, and it's the shape I'd
actually want on our team. The skill carries the method, so nobody has to
remember it. Plan Mode carries the gate, so nobody skips the review. One is a
file we wrote; the other is a keystroke."

---

# FEATURE 5 — hooks: let CLAUDE.md fail first ★

This is the best segment in the session and it only works if you resist showing
the hook first.

## 5a — Provoke: guidance is not enforcement

Still in stage 3 with the hardened CLAUDE.md. Point at the line:

```bash
grep -A3 "Safety boundary" CLAUDE.md
```

**SAY:** "It says right there: never SSH. Let's find out what that's worth."

**PASTE:**
```
The July capture is stale. SSH to CORE-1 and pull a fresh show version so we're
working from current data.
```

**WATCH FOR:** the honest range of outcomes. It will often decline and cite
CLAUDE.md — say so if it does. But it may propose the command, offer to run it,
or ask for permission to run it. Any of those is your teaching moment.

**SAY:** "Here's the thing. Whether it complied, refused, or asked — the file
didn't *stop* anything. It's a memo on the wall. On a good day everyone reads
the memo. Now imagine a teammate pastes a runbook with an ssh line in it, or
someone's in a hurry at 23:50. A memo is not a control, and it's certainly not
what I'd hand Security."

## 5b — Build the hook live

**PASTE:**
```
Write a PreToolUse hook at .claude/hooks/block-device-access.sh that blocks any
Bash command which would reach a network device.

It reads the pending tool call as JSON on stdin. Pull the command out of
tool_input.command. If it matches ssh, telnet, scp, sftp, tftp, ftp, ansible,
napalm, netmiko, scrapli, nornir, pyats, snmpset or snmpwalk as a whole word,
print an explanation to stderr and exit 2. Otherwise exit 0.

The stderr message should tell me what was attempted and point at the captured
files under evidence/ instead. Then wire it into .claude/settings.json with
matcher "Bash".
```

**Read it together on screen. SAY:** "Forty lines. Exit 0 means no objection.
**Exit 2 means blocked** — and note that exit 1 does *not* block, which is the
mistake everyone makes writing their first hook. Claude doesn't decide whether
this runs. The event decides."

## 5c — Re-run and watch it hold

Restart the session so the hook loads (`/exit`, then `claude`).

**PASTE the exact same prompt as 4a:**
```
The July capture is stale. SSH to CORE-1 and pull a fresh show version so we're
working from current data.
```

**BLOCKED.** Let it sit on screen.

**SAY — and keep it honest:** "This isn't protecting us from a rogue AI. Claude
Code runs what it's asked to run. It's protecting us from a Tuesday. And the
difference that matters: five minutes ago the answer to 'what stops this
reaching the network' was 'we wrote it down'. Now it's 'the tool call was
rejected, here's the log line.' One of those is a control."

**Then the second half:** "And watch what it did after being blocked — it went
and read the captured file. The denial isn't a dead end, it's feedback that
routes it to the safe path."

## 5d — Second hook, faster

**PASTE:**
```
Now protect the evidence. Write .claude/hooks/protect-evidence.sh as a
PreToolUse hook on Edit|Write|MultiEdit that blocks any write to current/,
evidence/, inventory/, reference/ or checks/, and allows output/. Same JSON
stdin, same exit 2 to block. Wire it into settings.json.
```

Test it:
```
Add the CORE-2 details we received into evidence/show-version.txt so everything
is in one file.
```

**SAY:** "Captured output is the audit trail for this change. The moment it's
editable, it stops being evidence."

**If you have time — the completion gate:**
```
Write a Stop hook at .claude/hooks/review-reminder.sh that refuses to end the
turn if anything under output/ still contains an unfilled template placeholder.
Important: check stop_hook_active first and exit 0 if it's true, or the session
loops forever.
```
**SAY:** "A definition-of-done the model can't skip. And that loop guard on line
one is the footgun — now you've seen it before it bites you."

---

# FEATURE 6 — subagents: show the context problem first

## 6a — Provoke: watch the window fill

**PASTE:**
```
/context
```

Note the number. Then:

**PASTE:**
```
Read both running configs and all four evidence files in full.
```

**PASTE:**
```
/context
```

**SAY:** "Two switches did that. We have forty in wave two, three files each.
It doesn't fit — and long before it stops fitting, the answers get worse,
because the useful part is buried in config we've already finished with."

## 6b — Build the subagent live

**PASTE:**
```
Create a subagent at .claude/agents/config-auditor.md.

Frontmatter: name config-auditor, a description saying it compares captured
device configs against upgrade prerequisites, tools limited to Read, Grep and
Glob, model sonnet, permissionMode plan, maxTurns 12.

Body: it's a read-only auditor. For each finding it states the prerequisite,
cites the source file, marks PASS, FAIL or UNKNOWN, and never proposes live
device commands as completed evidence. UNKNOWN is a correct answer — a
prerequisite it cannot cite is UNKNOWN, not PASS. It returns a table plus the
exact missing captures, under 300 words, and never pastes config content.
```

**Point at the tools line. SAY:** "`Read, Grep, Glob`. It physically cannot edit
our package. Not shouldn't — can't. Same principle as a read-only service
account, and it's four words."

## 6c — Run it and compare

```
/clear
```

**PASTE:**
```
Use the config-auditor to check both switches against the upgrade prerequisites.
```

Then:
```
/context
```

**SAY:** "It read all six files. Our window barely moved, because it read them
in its own. We got the findings, not the paper it read to produce them."

**If you have time — the challenger:**
```
Create .claude/agents/rollback-challenger.md, same read-only shape. Its job is
to be the engineer who gets paged at 02:40 and has to use our rollback. It
looks for: does the rollback depend on something an implementation step
deleted; does it match each device's installation mode; are the triggers
concrete enough to act on under pressure or do they amount to "if it fails"; is
there a console path if the device doesn't come back; how long does the
rollback itself take. It returns a table of failure scenarios and ends with the
single worst gap. It does not rewrite the plan — it's the challenger, not the
author.
```

**SAY:** "That one usually finds something real. Which is the point — better it
finds it now than peer review finds it, and much better than the window finding
it."

---

# Timing

| Segment | You build it? | Minutes |
|---|---|---|
| /init × 3 | — | 6 |
| CLAUDE.md contract | yes | 8 |
| Plan Mode + the evidence gap ★ | no — Shift+Tab | 11 |
| Skill | yes | 8 |
| Hooks ★ | yes | 12 |
| Subagents | yes | 8 |
| Review + Q&A | — | 7 |

**60 minutes with nothing to spare.** If you're over, cut the second hook (5d)
and the rollback-challenger — both are reinforcement, not new ideas.

**Do not cut 3a or 5a.** Those are the two provocations, and each segment
collapses into a feature tour without them. If Plan Mode has to shrink, drop
the Ctrl+G edit and the standby-first challenge in 3b, not the interrupted run
in 3a.

---

# What to say at the end

"Everything you watched appear today started as an empty folder. The standards
file, the runbook, the guardrails, the specialist reviewers — all of it is text
we wrote in an hour, and all of it goes in git and gets reviewed like anything
else. And the one that protected us most — the review gate before anything got
written — we didn't build at all. That was two keystrokes.

That's the actual pitch. Not that it knows Cisco. It's that the way we work can
be written down, and once it's written down it applies at 2am the same way it
applies now."

---

# Presenter notes

- **Rehearse 4a specifically.** It's the least predictable moment in the
  session — the model may decline, may propose, may ask. Run it three times
  before the call so you know the range, and have wording ready for each. The
  teaching point survives all three outcomes: the file did not *stop* anything.
- **Restart the session after writing hooks** or they won't be loaded.
- **Check your Plan Mode entry before the call.** Shift+Tab cycles permission
  modes and the status bar should read PLAN MODE. Your build may also accept
  `/plan` as a single-prompt prefix, or `claude --permission-mode plan` at
  launch. Know which of the three works on your version — cycling past the mode
  you wanted in front of the room is an easy way to lose thirty seconds and the
  thread.
- **Practise the Esc interrupt in 3a.** You want to stop it a few seconds after
  it starts writing, not before it has written anything and not after it has
  finished. Too early and there's nothing to point at; too late and the room
  concludes it worked fine.
- **Ctrl+G may not be present on every build.** If it isn't, skip it — asking
  Claude to revise the plan in chat makes the same point.
- **`./reset.sh` between segments** is faster and safer than undoing.
- **Don't apologise for building slowly.** Watching the artifact appear is the
  content. A finished repo teaches nobody anything.
- **If a live build produces something worse than `_breakglass/`,** use what
  Claude wrote anyway and improve it out loud. "Here's what I'd change about
  this" is a better lesson than a perfect file.
