# campus-core-lab

A teaching lab, not a finished repository. You build CLAUDE.md, the skill, the
hooks and the subagents **live**, while the audience watches. Start here:
**LAB-GUIDE.md**.

## Quick start

```bash
./reset.sh          # list the stages
./reset.sh 1        # load stage 1 into work/
cd work && claude
```

## The stages

| Stage | `work/` contains | Used for |
|---|---|---|
| 0 | nothing | `/init` on an empty repo — proves it reads what exists |
| 1 | evidence only, no CLAUDE.md | `/init` with real files to read |
| 2 | a thin auto-generated CLAUDE.md | `/init` over an existing file; then hardening it |
| 3 | the hardened CLAUDE.md | starting point for skill, hooks, subagents |

`./reset.sh <n>` wipes `work/` and reloads it. Nothing in `work/` is precious —
that's deliberate. Build it again next time.

## The teaching pattern

Every feature follows the same three beats:

1. **Provoke the problem** — do the work without the feature, let it go wrong
2. **Apply the fix live** — Claude writes the artifact, or you switch the
   feature on; you read what changed together
3. **Re-run** — same task, different outcome

Beat 1 is the one that teaches. Nobody remembers a hook they were shown.
Everybody remembers the SSH that went through, and then didn't.

**Six segments:** `/init` ×3 → CLAUDE.md → **Plan Mode** → skill → hooks →
subagents. Five of those you build. Plan Mode you just turn on with Shift+Tab —
worth saying out loud, so nobody leaves thinking this is all authoring work.

## The deliberate gap

`current/core2-running.txt` is truncated across its boot block and CORE-2's
section of `evidence/show-version.txt` ends in a dropped session. **Do not fix
this.** It is what makes Claude write `output/questions.md` instead of inventing
CORE-2's installation mode — the strongest moment in the session.

The missing capture sits in `_presenter-dropin/core2-recapture.txt`. Drop it in
when the guide says to (segment 3c). Payoff: CORE-1 is INSTALL mode, CORE-2 is
BUNDLE mode — two different upgrade procedures, and a guess would have looked
entirely reasonable.

The gap now surfaces **inside the Plan Mode segment**, as a missing-evidence line
in a plan you're being asked to approve. That is a stronger demonstration than it
was as a standalone step: the audience sees the unknown declared in a document,
before anything is written to disk.

## `_breakglass/`

Finished versions of everything you build live. Use only if a live build stalls:
copy it in, say "here's one I made earlier," keep moving. Don't open it
otherwise — and don't ship it to the team as the starting point, or they learn
nothing.

## After the session

The team's own repo should be built the same way: empty first, then their
evidence, then their rules. What they build themselves, they'll maintain.
